/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe_csd;

import java.time.LocalDate;
import java.util.Arrays;


/**
 *
 * @author ASUS
 */
public class EventManagementSystem {
    ArrayList list = new ArrayList();
    
    private int checkDuplicate(Event ev){
        for(int i = 0; i < list.size(); i++){
            if(list.get(i).getEventID().equals(ev.getEventID())){
                return i;
            }
        }
        return -1;
    }
    
    public void addEvent(Event newEvent){
        int index = checkDuplicate(newEvent);
        if(index == -1){
            list.add(newEvent);
            System.out.println("Added successfully.");
            return;
        }
        list.remove(index);
        list.add(index, newEvent);
    }
    
    public void remove(String id){
        for(int i = 0; i < list.size(); i++){
            if(list.get(i).equals(id)){
                list.remove(i);
                System.out.println("Deleted successfully.");
                return;
            }
        }
        System.out.println("Not found the given information.");
    }
    
    public ArrayList istUpcomingEvents(LocalDate currentDate){
        ArrayList result = new ArrayList();
        for(int i = 0; i < list.size(); i++){
            if(list.get(i).getEventDate().isAfter(currentDate)){
                list.add(list.get(i));
            }
        }
        return result;
    }
}

class Event{
    String eventID, eventName;
    LocalDate eventDate;
    int priority;

    public Event(String eventID, String eventName, LocalDate eventDate, int priority) {
        this.eventID = eventID;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.priority = priority;
    }

    public String getEventID() {
        return eventID;
    }

    public String getEventName() {
        return eventName;
    }

    public LocalDate getEventDate() {
        return eventDate;
    }

    public int getPriority() {
        return priority;
    }

    @Override
    public String toString() {
        return "Event{" + "eventID=" + eventID + ", eventName=" + eventName + ", eventDate=" + eventDate + ", priority=" + priority + '}';
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public void setEventDate(LocalDate eventDate) {
        this.eventDate = eventDate;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}



class ArrayList{
    private Event[] data;
    private int size;
    private static final int INITIAL_CAPACITY = 10;
    

    public ArrayList() {
        data = new Event[INITIAL_CAPACITY];
        size = 0;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void add(Event value) {
        if (size == data.length) {
            resize();
        }
        data[size++] = value;
    }

    public void add(int index, Event value) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index out of bounds.");
        }
        if (size == data.length) {
            resize();
        }
        for (int i = size; i > index; i--) {
            data[i] = data[i - 1];
        }
        data[index] = value;
        size++;
    }

    public Event get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds.");
        }
        return data[index];
    }

    public void remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds.");
        }
        for (int i = index; i < size - 1; i++) {
            data[i] = data[i + 1];
        }
        data[size - 1] = null;  // Clear the last element
        size--;
    }

    public boolean contains(Event value) {
        for (int i = 0; i < size; i++) {
            if (data[i].equals(value)) {
                return true;
            }
        }
        return false;
    }

    private void resize() {
        data = Arrays.copyOf(data, data.length * 2);
    }

    public void clear() {
        Arrays.fill(data, 0, size, null);
        size = 0;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i != size - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
    
    public void bubbleSortWithPriority() {
        int n = size;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (get(j).getPriority() > get(j + 1).getPriority()) {
                    // Swap arr[j] and arr[j+1]
                    Event temp = get(j);
                    data[j] = get(j + 1);
                    data [j + 1] = temp;
                    swapped = true;
                }
            } 
            // If no elements were swapped, break early
            if (!swapped) {
                break;
            }
        }
    }
    
    public void bubbleSortWithDate() {
        int n = size;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (get(j).getPriority() > get(j + 1).getPriority()) {
                    // Swap arr[j] and arr[j+1]
                    Event temp = get(j);
                    data[j] = get(j + 1);
                    data [j + 1] = temp;
                    swapped = true;
                }
            } 
            // If no elements were swapped, break early
            if (!swapped) {
                break;
            }
        }
    }       
}

