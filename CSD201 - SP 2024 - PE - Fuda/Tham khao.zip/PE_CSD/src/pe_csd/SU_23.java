package pe_csd;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class SU_23 {

    public static void main(String[] args) {
        Teacher[] teachers = {new Teacher(5, 5), new Teacher(3, 3),
            new Teacher(2, 2), new Teacher(4, 4), new Teacher(7, 7), new Teacher(6, 6),
            new Teacher(8, 8), new Teacher(1, 1), new Teacher(9, 9)};

        BST bst = new BST();
        bst.insertFromArray(teachers);
        System.out.println("PRINT: ");
        bst.printAllNodeByLevel();
        System.out.println("Icreament: ");
        bst.inceaseCoeffWithM();
        bst.printAllNodeByLevel();
        System.out.println("BAL: ");
        bst.updateBalance(bst.root);
        bst.preOrder(bst.root);
        System.out.println("Sort: ");
        BST.bubbleSort(teachers);
        Arrays.stream(teachers).forEach(System.out::println);
    }
}

class Teacher implements Comparable<Teacher> {

    private int code;
    private double coeff;

    public Teacher(int code, double coeff) {
        this.code = code;
        this.coeff = coeff;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setCoeff(double coeff) {
        this.coeff = coeff;
    }

    public int getCode() {
        return code;
    }

    public double getCoeff() {
        return coeff;
    }

    @Override
    public String toString() {
        return "Teacher{" + "code=" + code + ", coeff=" + coeff + '}';
    }

    @Override
    public int compareTo(Teacher o) {
        return Integer.compare(this.code, o.getCode());
    }

}

class BST {

    class Node {

        Teacher data;
        Node left;
        Node right;
        int balance;

        public Node(Teacher data) {
            this.data = data;
            left = null;
            right = null;
            balance = 0;
        }
    }

    Node root;

    public BST() {
        root = null;
    }

    public Node insertFromArray(Teacher[] teachers) {
        for (Teacher teacher : teachers) {
            insert(teacher);
        }
        return root;
    }

    // Insert a new node into the binary search tree
    public Node insert(Teacher data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }

        Node current = root;
        while (true) {
            if (data.compareTo(current.data) < 0) {
                if (current.left == null) {
                    current.left = new Node(data);
                    break;
                }
                current = current.left;
            } else if (data.compareTo(current.data) > 0) {
                if (current.right == null) {
                    current.right = new Node(data);
                    break;
                }
                current = current.right;
            } else {
                System.out.println("Binary search tree not allows duplicated value.");
                break;
            }
        }
        return root;
    }

    public void inceaseCoeffWithM() {
        Node max = findMax();
        double incement = (max.data.getCoeff() / 2.0);
        increaseCoeff(root, incement);
    }

    private void increaseCoeff(Node node, double increment) {
        if (node == null) {
            throw new IllegalStateException("The tree is empty");
        }
        Stack<Node> stack = new Stack<>();
        stack.add(root);
        while (!stack.isEmpty()) {
            Node current = stack.pop();
            current.data.setCoeff(current.data.getCoeff() + increment);
            if (current.left != null) {
                stack.add(current.left);
            }
            if (current.right != null) {
                stack.add(current.right);
            }
        }
    }

    public void printAllNodeByLevel() {
        if (root == null) {
            throw new IllegalStateException("The tree is empty");
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        int level = 0;
        while (!queue.isEmpty()) {
            int size = queue.size();
            for (int i = 0; i < size; i++) {
                Node current = queue.poll();
                System.out.println(current.data + ", level: " + level);
                if (current.left != null) {
                    queue.add(current.left);
                }
                if (current.right != null) {
                    queue.add(current.right);
                }
            }
            level++;
        }
    }

    // Pre-order traversal (recursive)
    public void preOrder(Node root) {
        if (root == null) {
            return;
        }
        System.out.print(root.data + " ");
        preOrder(root.left);
        preOrder(root.right);
    }

    // Find the maximum value in the tree
    public Node findMax() {
        if (root == null) {
            throw new IllegalStateException("Tree is empty.");
        }
        Node current = root;
        while (current.right != null) {
            current = current.right;
        }
        return current;
    }

    public void updateBalance(Node node) {
        if (node == null) {
            return;
        }
        // Get height of left and right subtrees in one traversal
        int leftHeight = height(node.left);
        int rightHeight = height(node.right);
        node.balance = leftHeight - rightHeight;

        // Recursively update balance factors for left and right subtrees
        updateBalance(node.left);
        updateBalance(node.right);
    }

    // Calculate the height of the tree
    public int height() {
        return height(root);
    }

    private int height(Node root) {
        if (root == null) {
            return 0;
        }
        int leftHeight = height(root.left);
        int rightHeight = height(root.right);
        return Math.max(leftHeight, rightHeight) + 1;
    }

    public static void bubbleSort(Teacher[] arr) {
        int n = arr.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) < 0) {
                    // Swap arr[j] and arr[j+1]
                    Teacher temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            // If no elements were swapped, break early
            if (!swapped) {
                break;
            }
        }
    }
}
