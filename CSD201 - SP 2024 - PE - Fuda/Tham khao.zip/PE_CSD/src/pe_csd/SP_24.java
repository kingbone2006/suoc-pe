/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe_csd;

import java.util.Arrays;
import java.util.Stack;

/**
 *
 * @author ASUS
 */
public class SP_24 {
    public static void main(String[] args) {
        Task[] tasks = {new Task(1, "Security patch for vulnerability", 100),
        new Task(2, "Add login feature", 80),
        new Task(3, "Update documentation", 40),
        new Task(4, "Fix email notification", 90),
        new Task(5, "Refactor user management module", 70),
        new Task(6, "Implement data caching", 85),
        new Task(7, "Optimize database queries", 75),
        new Task(8, "Write unit tests for new features", 60),
        new Task(9, "Upgrade third-party libraries", 50),
        new Task(10, "Review and merge pull requests", 55)};
        //Advantages: 
        //+Array su dung radom access nen chi toi O(1) de truy cap vao cac phan tu tai index cho truoc
        //+Array la mot mang khong mang dong nen se de trien khai
        //Disadvantages:
        //+insert va xoa tai mot index cho truoc se ton O(n) tai vi phai dich chuyen cac phan tu sang vi cac phan tu trong 
        //Array deu phai lien ke nhau
        for(Task task : tasks){
            System.out.println(task);
        }
        //Merge Sort stable:
        //-> Tai vi chung ta se merge nhung mang con da duoc sap xep trong recusive nen khi merge lai thi neu a1 nho a2 trong
        //mang con A thi neu co phan tu cua mang con B vd b2 lon hon a1 nhung nho hon a2 thi a2 van xep sau a1 va van giu duoc tinh
        //stable
        //Quick Sort not stable:
        //Tai vi idea cua Quick Sort la dua nhung phan tu nho hon pivot sang ben trai pivot va lon hon thi ben phai
        //nen tuy thuoc vao pivot khi duoc chon trong recursive thi phan tu do co the doi vi tri cho nhau va khong con stable
        //vd 137258 pivot la 5 thi ban dau 3 dung truoc 2 nhung sau do thi 3 dung sau 2 
        MaxHeap maxheap = new MaxHeap(11);
        SP_24.mergeSort(tasks, 0, tasks.length - 1);
        System.out.println("Cau 3: ");
        System.out.println("___________________");
        for(Task ta : tasks){
            System.out.println(ta);
            maxheap.insert(ta);
        }
        
        System.out.println("cau 5: ");
        System.out.println("____");
        maxheap.preOrder(0);
        //Heap
        //+Insert va delete chi ton O(logn) vi cay nay la cay theo idea cha lon hon con va la mot cay complete tuc la balanced tree
        //khi do khi insert hay delete thi hepifyDown hay hepifyUp chi ton theo chieu cao cua cay la O(logn)
        System.out.println("Cau 4: ");
        System.out.println("__________________");
        System.out.println(maxheap.getSize());
        do{
            System.out.println(maxheap.remove());
        } while (maxheap.getSize() != 0);
        
        
    }
    
    public static void mergeSort(Task[] array, int left, int right) {
        if (left < right) {
            // Find the middle point
            int mid = left + (right - left) / 2;

            // Recursively sort first and second halves
            mergeSort(array, left, mid);
            mergeSort(array, mid + 1, right);

            // Merge the sorted halves
            merge(array, left, mid, right);
        }
    }

    public static void merge(Task[] array, int left, int mid, int right) {
        // Sizes of the two subarrays
        int n1 = mid - left + 1;
        int n2 = right - mid;

        // Temporary arrays
        Task[] leftArray = new Task[n1];
        Task[] rightArray = new Task[n2];

        // Copy data to temporary arrays
        for (int i = 0; i < n1; i++) {
            leftArray[i] = array[left + i];
        }
        for (int j = 0; j < n2; j++) {
            rightArray[j] = array[mid + 1 + j];
        }

        // Merge the temporary arrays
        // Initial indexes of the left and right subarrays
        int i = 0, j = 0;

        // Initial index of the merged array
        int k = left;
        while (i < n1 && j < n2) {
            if (leftArray[i].compareTo(rightArray[j]) <= 0) {
                array[k] = leftArray[i];
                i++;
            } else {
                array[k] = rightArray[j];
                j++;
            }
            k++;
        }

        // Copy the remaining elements of leftArray, if any
        while (i < n1) {
            array[k] = leftArray[i];
            i++;
            k++;
        }

        // Copy the remaining elements of rightArray, if any
        while (j < n2) {
            array[k] = rightArray[j];
            j++;
            k++;
        }
    }

}

class Task implements Comparable<Task>{
    private int ID, priority;
    private String descreption;

    public Task(int ID, String descreption , int priority) {
        this.ID = ID;
        this.priority = priority;
        this.descreption = descreption;
    }

    public int getID() {
        return ID;
    }

    public int getPriority() {
        return priority;
    }

    public String getDescreption() {
        return descreption;
    }

    @Override
    public String toString() {
        return "Task{" + "ID=" + ID + ", priority=" + priority + ", descreption=" + descreption + '}';
    }

    @Override
    public int compareTo(Task o) {
        return Integer.compare(this.priority, o.getPriority());
    }
}


class MaxHeap {
    private Task[] heap;
    private int size;
    private int capacity;

    public MaxHeap(int capacity) {
        this.capacity = capacity;
        this.size = 0;
        this.heap = new Task[capacity];
    }

    public Task[] getHeap() {
        return heap;
    }

    public int getSize() {
        return size;
    }
    
    

    private int parent(int i) { return (i - 1) / 2; }
    private int leftChild(int i) { return 2 * i + 1; }
    private int rightChild(int i) { return 2 * i + 2; }

    // Insert a new element into the heap
    public void insert(Task value) {
        if (size == capacity) increaseCapacity();
        heap[size] = value;
        size++;
        heapifyUp(size - 1);
    }


    // Delete an element at a specific index
    public Task remove() {
        if(size == 0)
            throw new IllegalStateException("Heap is empty");
        Task removeTask = heap[0];
        heap[0] = heap[size - 1];
        heap[size - 1] = null; // Clear reference to removed element
        size--;
        
        heapifyDown(0);
        return removeTask;
    }

    // Build heap from an existing array

    // Heapify up to maintain the max-heap property
    private void heapifyUp(int i) {
        Task temp = heap[i];
        while (i > 0 && temp.compareTo(heap[parent(i)]) > 0) {
            heap[i] = heap[parent(i)];
            i = parent(i);
        }
        heap[i] = temp;
    }

    // Heapify down to maintain the max-heap property
    private void heapifyDown(int i) {
    while (true) {
        int greatest = i;
        int left = leftChild(i);
        int right = rightChild(i);

        if (left < size && heap[left].compareTo(heap[greatest]) > 0) {
            greatest = left;
        }

        if (right < size && heap[right].compareTo(heap[greatest]) > 0) {
            greatest = right;
        }

        // Nếu `smallest` không thay đổi, heap đã hợp lệ
        if (greatest == i) {
            break;
        }

        // Hoán đổi và cập nhật chỉ số `i` để tiếp tục duy trì heap
        swap(i, greatest);
        i = greatest;
        }
    }

    // Swap elements in the heap array
    private void swap(int i, int j) {
        Task temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    // Increase the capacity of the heap array
    private void increaseCapacity() {
        capacity *= 2;
        heap = Arrays.copyOf(heap, capacity);
        System.out.println("Heap capacity increased to " + capacity);
    }

    // Print heap elements
    public void printHeap() {
        System.out.println("Heap array: " + Arrays.toString(Arrays.copyOf(heap, size)));
    }
    
    public void preOrder(int i){
        if(i > size)
            return;
        Stack<Task> stack = new Stack<>();
        stack.push(heap[i]);
        while(!stack.isEmpty()){
            Task current = stack.pop();
            int currentIndex = -1;
            for(int j = 0; j < size; j++){
                if(heap[j]!= null && heap[j].getID() == current.getID()) {
                    currentIndex = j;
                    break;
                }
            }
            if(currentIndex == -1)
                continue;
            System.out.println(current);
            if((2 * currentIndex + 2) < size && heap[2 * currentIndex + 2] != null)
                stack.push(heap[2 * currentIndex + 2]);
            if((2 * currentIndex + 1) < size && heap[2 * currentIndex + 1] != null)
                stack.push(heap[2 * currentIndex + 1]);
        }
    }
}


