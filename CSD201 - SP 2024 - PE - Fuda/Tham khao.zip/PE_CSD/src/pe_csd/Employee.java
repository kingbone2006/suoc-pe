package pe_csd;

import java.util.*;

public class Employee implements Comparable<Employee> {
    private int id, yearOfBirth;
    private String fullName;
    private double salary;

    public Employee(int id, String fullName, int yearOfBirth, double salary) {
        this.id = id;
        this.yearOfBirth = yearOfBirth;
        this.fullName = fullName;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }

    public String getFullName() {
        return fullName;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Employee{");
        sb.append("id=").append(id);
        sb.append(", yearOfBirth=").append(yearOfBirth);
        sb.append(", fullName='").append(fullName).append('\'');
        sb.append(", salary=").append(salary);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int compareTo(Employee o) {
        return Integer.compare(this.id, o.getId());
    }
}


class CQueue {
    int size;
    int front, rear;
    int items[];

    public CQueue(int size) {
        this.size = size;
        front = -1;
        rear = -1;
        items = new int[size];
    }

    boolean isFull() {
        return (front == 0 && rear == size - 1) || (front == rear + 1);
    }

    boolean isEmpty() {
        return front == -1;
    }

    void enQueue(int element) {
        if (isFull()) {
            System.out.println("Queue is full");
        } else {
            if (front == -1)
                front = 0;
            rear = (rear + 1) % size;
            items[rear] = element;
            System.out.println("Inserted " + element + " at " + rear);
        }
    }

    int deQueue() {
        int element;
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return -1;
        } else {
            element = items[front];
            if (front == rear) {
                front = -1;
                rear = -1;
            } else {
                front = (front + 1) % size;
            }
            return element;
        }
    }

    void display() {
        int i;
        if (isEmpty()) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Front -> " + front);
            System.out.print("Item -> ");
            for (i = front; i != rear; i = (i + 1) % size) {
                System.out.print(items[i] + " ");
            }
            System.out.println(items[i]);
            System.out.println("Rear -> " + rear);
        }
    }
}

class Node {
    Employee data;
    Node left;
    Node right;
    public Node(Employee data){
        this.data = data;
        left = null;
        right = null;
    }
}

class BST {
    Node root;

    public BST() {
        root = null;
    }


    public Node insert (Employee data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }

        Node current = root;
        while (true) {
            if (data.compareTo(current.data) < 0) {
                if (current.left == null) {
                    current.left = new Node(data);
                    break;
                }
                current = current.left;
            } else if (data.compareTo(current.data) > 0) {
                if (current.right == null) {
                    current.right = new Node(data);
                    break;
                }
                current = current.right;
            } else {
                System.out.println("Binary search tree not allows duplicated value.");
                break;
            }
        }
        return root;
    }

    public Employee getMinSalary(){
        if(root == null)
            throw new IllegalStateException("Tree is empty");

        Employee min =  null;
        double minSalary = Double.MAX_VALUE;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while(!queue.isEmpty()) {
            Node current = queue.poll();
            if(current.data.getSalary() < minSalary){
                min = current.data;
                minSalary = current.data.getSalary();
            }
            if(current.left != null)
                queue.add(current.left);
            if(current.right != null)
                queue.add(current.right);
        }
        return min;
    }

    public Employee[] traversal(Node node, Employee[] list){
        if(node == null)
            return null;

        traversal(node.right, list);
        for(int i = 0; i < list.length; i++){
            if (list[i] == null) {
                list[i] = node.data;
                break;
            }
        }
        System.out.println(node.data);
        traversal(node.left, list);
        return list;
    }

    public int findHeight() {
        if (root == null) {
            return 0;
        }

        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        int height = 0;

        while (!queue.isEmpty()) {
            int nodesAtCurrentLevel = queue.size();
            height++;

            // Process all nodes at the current level
            for (int i = 0; i < nodesAtCurrentLevel; i++) {
                Node current = queue.poll();

                // Enqueue left and right children
                if (current.left != null) {
                    queue.add(current.left);
                }
                if (current.right != null) {
                    queue.add(current.right);
                }
            }
        }

        return height;
    }

    public static void selectionSort(Employee[] arr) {
        int n = arr.length;

        for (int i = 0; i < n - 1; i++) {
            // Tìm chỉ số của phần tử nhỏ nhất trong mảng con
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j].compareTo(arr[minIndex]) > 0) {
                    minIndex = j;
                }
            }

            // Đổi chỗ phần tử nhỏ nhất với phần tử đầu tiên của mảng con
            Employee temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }
}

class Test1 {
    public static void main(String[] args) {
        Employee[] emps = new Employee[]{
                new Employee(5, "John", 2004, 5000),
                new Employee(3, "David", 2003, 3000),
                new Employee(2, "Kevin", 2005, 4000),
                new Employee(4, "Paul", 2005, 6000),
                new Employee(7, "Joe", 2004, 7000),
                new Employee(6, "July", 2003, 9000),
                new Employee(8, "Anna", 2004, 8000),
                new Employee(1, "Bob" , 2005, 5000),
                new Employee(9, "Dona", 2005, 6000)
        };
        BST bst = new BST();
        //cau1:
        for(Employee emp : emps){
            bst.insert(emp);
        }

        //cau2:

        Employee rs = bst.getMinSalary();
        System.out.println(rs);

        // cau3:
        Employee[] list = new Employee[9];
        Employee[] ain = bst.traversal(bst.root, list);

        System.out.println("-------");
        for(Employee emp : ain){
            if(emp != null)
                System.out.println(emp);
        }

        // cau4:
        System.out.println(bst.findHeight());

        // cau5:
        BST.selectionSort(emps);
        for(Employee emp : emps)
            System.out.println(emp);
        boolean check = true;
        for(int i = 0; i < emps.length; i++){
            if(emps[i].getId() != ain[i].getId()){
                check = false;
                break;
            }
        }
        if(!check)
            System.out.println("Two array not equal");
        else
            System.out.println("Equal");
    }
}

