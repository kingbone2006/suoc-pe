package pe_csd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

// Lớp Student để lưu thông tin sinh viên
class Student implements Comparable<Student> {
    private int id;
    private String name;
    private String major;
    private float score;

    public Student(int id, String name, String major, float score) {
        this.id = id;
        this.name = name;
        this.major = major;
        this.score = score;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMajor() {
        return major;
    }

    public float getScore() {
        return score;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name='" + name + "', major='" + major + "', score=" + score + '}';
    }

    @Override
    public int compareTo(Student o) {
        return Float.compare(this.score, o.score);
    }
}

public class FA_CSD {
    public static void bubbleSort(Student[] arr) {
        int n = arr.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // Swap arr[j] and arr[j+1]
                    Student temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            // If no elements were swapped, break early
            if (!swapped) {
                break;
            }
        }
    }

    public static void main(String[] args) {
        MinHeap minHeap = new MinHeap(10);

        minHeap.insert(new Student(1, "Minh Nguyen", "SE", 8.0f));
        minHeap.insert(new Student(2, "Hanh Phan", "IB", 7.0f));
        minHeap.insert(new Student(3, "Tuan Le", "AI", 3.0f));
        minHeap.insert(new Student(4, "Ngo Nguyen", "SE", 9.0f));
        minHeap.insert(new Student(5, "Hoa Pham", "IB", 4.0f));
        minHeap.insert(new Student(6, "Tung Tran", "SE", 7.5f));

        System.out.println("Pre-order traversal of the heap:");
        System.out.println("Cau 1: ");
        minHeap.preOrderTraversal();
        System.out.println("Cau 2: ");
        System.out.println(minHeap.searchByName("Tung Tran"));
        minHeap.deleteById(6);
        System.out.println("Cau 3: ");
        minHeap.preOrderTraversal();
        System.out.println("Cau 4: ");
        System.out.println(minHeap.getMaxScore());
        System.out.println("Cau 5: ");
        Student[] temp = Arrays.copyOf(minHeap.getHeap(), minHeap.getSize());
        FA_CSD.bubbleSort(temp);
        for (Student stu : temp)
            System.out.println(stu);
    }
}

// Lớp MinHeap để quản lý heap
class MinHeap {
    private Student[] heap;
    private int size;
    private int capacity;

    public MinHeap(int capacity) {
        this.capacity = capacity;
        this.size = 0;
        this.heap = new Student[capacity];
    }

    public int getSize() {
        return size;
    }

    public Student[] getHeap() {
        return heap;
    }

    public void insert(Student newStudent) {
        if (size == capacity) {
            increaseCapacity();
        }
        heap[size++] = newStudent;
        heapifyUp(size - 1);
    }

    public Student peek() {
        if (size == 0) {
            throw new IllegalStateException("Heap is empty");
        }
        return heap[0];
    }

    public Student poll() {
        if (size == 0) {
            throw new IllegalStateException("Heap is empty");
        }
        Student root = heap[0];
        heap[0] = heap[size - 1];
        heap[size - 1] = null;
        size--;
        heapifyDown(0);
        return root;
    }
    public Student delete(int index){
        if(size == 0)
            throw new IllegalStateException("Heap is empty.");
        Student temp = heap[index];
        heap[index] = heap[size - 1];
        heap[size - 1] = null;
        size--;
        heapifyDown(index);
        return temp;
    }
    public Student deleteById(int id){
        Student temp = null;
        for(int i = 0; i < size; i++){
            if(heap[i].getId() == id){
                temp = heap[i];
                delete(i);
                break;
            }
        }
        return temp;
    }

    public Student getMaxScore(){
        Student max = heap[0];
        for(int i = 1; i < size; i++){
            if(max.getScore() < heap[i].getScore()){
                max = heap[i];
            }
        }
        return max;
    }

    private void heapifyUp(int i) {
        Student temp = heap[i];
        while (i > 0 && temp.compareTo(heap[parent(i)]) < 0) {
            heap[i] = heap[parent(i)];
            i = parent(i);
        }
        heap[i] = temp;
    }

    private void heapifyDown(int i) {
        while (true) {
            int smallest = i;
            int left = leftChild(i);
            int right = rightChild(i);

            if (left < size && heap[left].compareTo(heap[smallest]) < 0) {
                smallest = left;
            }
            if (right < size && heap[right].compareTo(heap[smallest]) < 0) {
                smallest = right;
            }
            if (smallest == i) break;
            swap(i, smallest);
            i = smallest;
        }
    }

    private void swap(int i, int j) {
        Student temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    private void increaseCapacity() {
        capacity *= 2;
        heap = Arrays.copyOf(heap, capacity);
    }

    private int parent(int i) {
        return (i - 1) / 2;
    }

    private int leftChild(int i) {
        return 2 * i + 1;
    }

    private int rightChild(int i) {
        return 2 * i + 2;
    }


    public void preOrderTraversal() {
        if (size == 0) return;
        preOrder(0);
    }

    public void preOrder(int i){
        if(i > size)
            return;
        Stack<Student> stack = new Stack<>();
        stack.push(heap[i]);
        while(!stack.isEmpty()){
            Student current = stack.pop();
            int currentIndex = -1;
            for(int j = 0; j < size; j++){
                if(heap[j]!= null && heap[j].getId() == current.getId()) {
                    currentIndex = j;
                    break;
                }
            }
            if(currentIndex == -1)
                continue;
            System.out.println(current);
            if((2 * currentIndex + 2) < size && heap[2 * currentIndex + 2] != null)
                stack.push(heap[2 * currentIndex + 2]);
            if((2 * currentIndex + 1) < size && heap[2 * currentIndex + 1] != null)
                stack.push(heap[2 * currentIndex + 1]);
        }
    }

    public Student searchByName(String name){
        Student temp = null;
        for(Student st : heap){
            if(st.getName().equalsIgnoreCase(name)) {
                temp = st;
                break;
            }
        }
        return temp;
    }
}

