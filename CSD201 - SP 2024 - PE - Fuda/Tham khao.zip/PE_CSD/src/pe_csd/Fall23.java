/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe_csd;

import java.util.Stack;

/**
 *
 * @author ASUS
 */
class Country implements Comparable<Country> {

    private int code;
    private int rank;
    private String name;
    private double GDP;

    public Country(int code, int rank, String name, double GDP) {
        this.code = code;
        this.rank = rank;
        this.name = name;
        this.GDP = GDP;
    }

    public int getCode() {
        return code;
    }

    public int getRank() {
        return rank;
    }

    public String getName() {
        return name;
    }

    public double getGDP() {
        return GDP;
    }

    @Override
    public String toString() {
        return "Country{" + "code=" + code + ", rank=" + rank + ", name=" + name + ", GDP=" + GDP + '}';
    }

    @Override
    public int compareTo(Country o) {
        return this.name.compareTo(o.getName());
    }

    public static void quickSort(Country[] arr, int low, int high) {
        if (low < high) {  // Điều kiện dừng đệ quy
            int pi = partition(arr, low, high);

            // Đệ quy lên phần tử bên trái và bên phải của pivot
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private static int partition(Country[] arr, int low, int high) {
        Country pivot = arr[high];  // Chọn pivot là phần tử cuối cùng
        int left = low - 1;

        // Di chuyển các phần tử nhỏ hơn pivot sang bên trái, lớn hơn pivot sang bên phải
        for (int right = low; right < high; right++) {
            if (arr[right].compareTo(pivot) < 0) {
                left++;
                // Hoán đổi arr[left] và arr[right]
                Country temp = arr[left];
                arr[left] = arr[right];
                arr[right] = temp;
            }
        }

        // Hoán đổi arr[left + 1] với pivot để đặt pivot vào vị trí đúng
        Country temp = arr[left + 1];
        arr[left + 1] = arr[high];
        arr[high] = temp;

        return left + 1;  // Trả về vị trí của pivot
    }
}

class AVLTree {

    private Node root;

    public AVLTree() {
        root = null;
    }

    class Node {

        Country key;
        int height;
        Node left, right;

        Node(Country key) {
            this.key = key;
            this.height = 1;
        }
    }

    // Get height of the node
    private int height(Node node) {
        return node == null ? 0 : node.height;
    }

    // Update height of the node
    private void updateHeight(Node node) {
        node.height = Math.max(height(node.left), height(node.right)) + 1;
    }

    // Get balance factor of the node
    private int getBalance(Node node) {
        return node == null ? 0 : height(node.left) - height(node.right);
    }

    // Right rotation
    private Node rightRotate(Node y) {
        Node x = y.left;
        y.left = x.right;
        x.right = y;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    // Left rotation
    private Node leftRotate(Node x) {
        Node y = x.right;
        x.right = y.left;
        y.left = x;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    // Insert a key into the AVL tree
    public void insert(Country key) {
        if (root == null) {
            root = new Node(key); // If the tree is empty, insert directly as root
            return;
        }

        Node current = root;
        Node parent = null;
        Stack<Node> path = new Stack<>();

        // Traverse the tree iteratively to find the insertion point
        while (current != null) {
            parent = current;
            path.push(current);
            if (key.compareTo(current.key) < 0) {
                current = current.left;
            } else if (key.compareTo(current.key) > 0) {
                current = current.right;
            } else {
                return; // Duplicate keys not allowed
            }
        }

        // Create the new node
        Node newNode = new Node(key);
        if (key.compareTo(parent.key) < 0) {
            parent.left = newNode;
        } else {
            parent.right = newNode;
        }

        // Perform the rebalancing from the insertion point upwards
        current = newNode;
        while (!path.isEmpty()) {
            parent = path.pop();
            updateHeight(parent);
            Node balancedNode = balance(parent);

            if (parent == root) {
                root = balancedNode;
            } else {
                if (parent == path.peek().left) {
                    path.peek().left = balancedNode;
                } else {
                    path.peek().right = balancedNode;
                }
            }
        }
    }

    public void delete(Country key) {
        if (root == null) {
            return;
        }

        Node current = root;
        Node parent = null;
        Stack<Node> path = new Stack<>();

        // Traverse the tree to find the node to delete
        while (current != null) {
            parent = current;
            path.push(current);
            if (key.compareTo(current.key) < 0) {
                current = current.left;
            } else if (key.compareTo(current.key) > 0) {
                current = current.right;
            } else {
                break; // Node to delete found
            }
        }

        if (current == null) {
            System.out.println("Node not found.");
            return; // Node to delete not found
        }

        // Case 1: Node has one or no child
        if (current.left != null && current.right != null) {
            Node successorParent = current;
            Node successor = current.right;
            while (successor.left != null) {
                successorParent = successor;
                path.push(successor); // Track path for rebalancing
                successor = successor.left;
            }
            
            current.key = successor.key;
            current = successor;
            parent = successorParent;
        } 
        
        Node child = (current.left != null) ? current.left : current.right;
        
        if(parent == null){
            root = child;
        }
        else if(parent.left == current){
            parent.left = child;
        } else {
            parent.right = child;
        }
        // After deletion, balance the tree from the parent up to the root
        while (!path.isEmpty()) {
            parent = path.pop();
            updateHeight(parent);
            Node balancedNode = balance(parent);

            if (!path.isEmpty()) {
                root = balancedNode;
                Node GrandParent = path.peek();
                if (parent == GrandParent.left) {
                    GrandParent.left = balancedNode;
                } else {
                    GrandParent.right = balancedNode;
                }
            } else {
                root = balancedNode;
            }
        }
    }

    private Node balance(Node node) {
        int balance = getBalance(node);

        // If the node is already balanced, no action is needed
        if (balance >= -1 && balance <= 1) {
            return node;
        }

        // Left Heavy Tree (Left-Left or Left-Right case)
        if (balance > 1) {
            // Left-Left Case: Single right rotation
            if (getBalance(node.left) >= 0) {
                return rightRotate(node);
            }
            // Left-Right Case: Double rotation (left followed by right)
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // Right Heavy Tree (Right-Right or Right-Left case)
        if (balance < -1) {
            // Right-Right Case: Single left rotation
            if (getBalance(node.right) <= 0) {
                return leftRotate(node);
            }
            // Right-Left Case: Double rotation (right followed by left)
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node; // Node is balanced, return as is
    }

    // Non-recursive inorder traversal
    public void inorder() {
        Stack<Node> stack = new Stack<>();
        Node current = root;
        int count = 0;
        while (current != null || !stack.isEmpty()) {
            while (current != null) {
                stack.push(current);
                current = current.left;
            }
            current = stack.pop();
            if (current.key.getName().charAt(0) == 'a') {
                count++;
            }
            System.out.println(current.key);
            current = current.right;
        }
        System.out.println(count);
    }
}

class Test {

    public static void main(String[] args) {
        // Create an array of countries
        Country[] countries = {
            new Country(1, 5, "Australia", 1500.0),
            new Country(2, 3, "VietName", 500.0),
            new Country(3, 1, "ThaiLand", 21000.0),
            new Country(4, 4, "Austria", 700.0),
            new Country(5, 2, "Afghanistan", 80.0)
        };

        // Sort the array using quickSort
        Country.quickSort(countries, 0, countries.length - 1);

        // Create an AVL tree instance
        AVLTree avlTree = new AVLTree();

        // Insert countries into the AVL tree
        System.out.println("Sort: ");

        for (Country country : countries) {
            System.out.println(country);
            avlTree.insert(country);
        }

        // Print the AVL tree using in-order traversal and count countries starting with 'a'
        System.out.println("In-order traversal of the AVL tree:");
        avlTree.inorder();

        // Example of deleting a country from the AVL tree (e.g., "Australia")
        System.out.println("\nDeleting 'Australia' from the AVL tree...");
        avlTree.delete(new Country(1, 5, "Australia", 1500.0));

        // Print the AVL tree after deletion
        System.out.println("\nIn-order traversal of the AVL tree after deletion:");
        avlTree.inorder();

        // Example of updating a country (e.g., changing GDP of "Afghanistan")
        System.out.println("\nUpdating 'Afghanistan' GDP...");
        // You would need to add a method to update the Country inside the AVL tree
        // Assuming there's a method to find and update the node
        // avlTree.update(new Country(5, 2, "Afghanistan", 100.0)); 

        // In order to update the country, you'd have to delete it first and then reinsert it with the updated value.
        avlTree.delete(new Country(5, 2, "Afghanistan", 80.0));
        avlTree.insert(new Country(5, 2, "Afghanistan", 100.0));

        // Print the AVL tree after updating
        System.out.println("\nIn-order traversal of the AVL tree after update:");
        avlTree.inorder();
    }

}
