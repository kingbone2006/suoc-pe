// PE_SP25_Q1.java

class Motorbike {
    int id;
    String name;
    String model;
    int engineCapacity;

    public Motorbike(int id, String name, String model, int engineCapacity) {
        this.id = id;
        this.name = name;
        this.model = model;
        this.engineCapacity = engineCapacity;
    }

    @Override
    public String toString() {
        return id + ". " + name + " - " + model + " - " + engineCapacity + "cc";
    }
}

class Node {
    Motorbike data;
    Node next;

    public Node(Motorbike data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public void addFirst(Motorbike m) {
        Node newNode = new Node(m);
        newNode.next = head;
        head = newNode;
    }

    public void removeLast() {
        if (head == null || head.next == null) {
            head = null;
            return;
        }
        Node current = head;
        while (current.next.next != null) {
            current = current.next;
        }
        current.next = null;
    }

    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }
}

public class PE_SP25_Q1 {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.addFirst(new Motorbike(10, "Royal Enfield Interceptor 650", "Interceptor650-2024", 648));
        list.addFirst(new Motorbike(9, "Triumph Street Triple RS", "TripleRS-2023", 765));
        list.addFirst(new Motorbike(8, "Harley-Davidson Iron 883", "Iron883-2024", 883));
        list.addFirst(new Motorbike(7, "BMW S1000RR", "S1000RR-2023", 999));
        list.addFirst(new Motorbike(6, "Ducati Panigale V4", "PanigaleV4-2024", 1103));
        list.addFirst(new Motorbike(5, "KTM Duke 390", "Duke390-2024", 373));
        list.addFirst(new Motorbike(4, "Suzuki GSX-R750", "GSX-R750-2023", 750));
        list.addFirst(new Motorbike(3, "Kawasaki Ninja 650", "Ninja650-2024", 649));
        list.addFirst(new Motorbike(2, "Yamaha YZF-R3", "YZF-R3-2023", 321));
        list.addFirst(new Motorbike(1, "Honda CBR500R", "CBR500R-2024", 500));

        System.out.println("Original list:");
        list.printList();

        System.out.println("\nAfter removing last:");
        list.removeLast();
        list.printList();
    }
}
