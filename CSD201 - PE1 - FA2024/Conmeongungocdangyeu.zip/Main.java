/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Employee {
    private int id;
    private String name;
    private String department;
    private int seniority;
    
    public Employee(){   
    }
    public Employee(int id, String name, String department, int seniority) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.seniority = seniority;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getSeniority() {
        return seniority;
    }

    public void setSeniority(int seniority) {
        this.seniority = seniority;
    }
    //fix text in list
    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Department: " + department + ", Seniority: " + seniority;
    }
}

class Node {
    Employee employee;
    Node left;
    Node right;
    int height;

    public Node(Employee employee) {
        this.employee = employee;
        this.height = 1;
    }
}

class BST {
    private Node root;

    public void insert(Employee employee) {
        root = insertRec(root, employee);
    }
    private Node insertRec(Node node, Employee employee) {
        if(node == null) {
            return new Node(employee);
        }
        if(employee.getId() < node.employee.getId()) {
            node.left = insertRec(node.left, employee);
        }else if (employee.getId() > node.employee.getId()) {
            node.right = insertRec(node.right, employee);
        }

        node.height = 1 + Math.max(getHeight(node.left),getHeight(node.right));
        return node;
    }
    public void inOrder() {
        inOrderRec(root);
    }
    private void inOrderRec(Node node) {
        if (node != null) {
            inOrderRec(node.left);
            System.out.println(node.employee);
            inOrderRec(node.right);
        }
    }

    public Employee search(String name) {
        return searchRec(root, name);
    }

    private Employee searchRec(Node node, String name) {
        if (node == null) return null;
        
        if (node.employee.getName().equals(name)) {
            return node.employee;
        }
        
        Employee left = searchRec(node.left, name);
        if (left != null) return left;
        
        return searchRec(node.right, name);
    }

    public void delete(int id) {
        root = deleteRec(root, id);
    }

    private Node deleteRec(Node node, int id) {
        if (node == null){
          return null;
        }
        if (id < node.employee.getId()){
           node.left = deleteRec(node.left, id);
        }else if (id > node.employee.getId()){
            node.right = deleteRec(node.right, id);
        }else {
            if (node.left == null) return node.right;
            else if (node.right == null) return node.left;
            Node successor = getMin(node.right);
            node.employee = successor.employee;
            node.right = deleteRec(node.right, successor.employee.getId());
        }
        return node;
    }

    private Node getMin(Node node) {
        while (node.left != null){
            node = node.left;
        }
        return node;
    }
    public boolean isBalanced() {
        return isBalancedRec(root);
    }
    private boolean isBalancedRec(Node node) {
        if (node == null) return true;
        int balance = getHeight(node.left) - getHeight(node.right);
        return Math.abs(balance) <= 1 && isBalancedRec(node.left) && isBalancedRec(node.right);
    }
    private int getHeight(Node node) {
        if (node == null) return 0;
        return node.height;
    }
    public Employee findMaxSeniority() {
        return findMaxSeniorityRec(root);
    }
    private Employee findMaxSeniorityRec(Node node) {
        if (node == null) return null;
        Employee maxEmployee = node.employee;
        Employee leftMax = findMaxSeniorityRec(node.left);
        Employee rightMax = findMaxSeniorityRec(node.right);
        if (leftMax != null && leftMax.getSeniority() > maxEmployee.getSeniority()) {
            maxEmployee = leftMax;
        }
        if (rightMax != null && rightMax.getSeniority() > maxEmployee.getSeniority()) {
            maxEmployee = rightMax;
        }
        return maxEmployee;
    }
}

public class Main {
    public static void main(String[] args) {
        BST bst = new BST();
        
        //create data
        bst.insert(new Employee(104, "Nam Nguyen", "HR", 5));
        bst.insert(new Employee(102, "Linh Phan", "IT", 1));
        bst.insert(new Employee(103, "Minh Le", "Finance", 3));
        bst.insert(new Employee(101, "Ngoc Nguyen", "IT", 6));
        bst.insert(new Employee(107, "Huong Pham", "Finance", 3));
        bst.insert(new Employee(106, "Tuan Tran", "Finance", 2));
        bst.insert(new Employee(108, "Hang Le", "IT", 4));
        bst.insert(new Employee(105, "Hung Nguyen", "IT", 5));

        //print inorder
        System.out.println("List of all employees:");
        bst.inOrder();
        
        //search minhle
        System.out.println("\nSearch for Minh Le:");
        Employee found = bst.search("Minh Le");
        if (found != null) {
            System.out.println("Found: " + found);
        } else {
            System.out.println("Employee not found");
        }
        
        //check BST
        System.out.println("\nBST balanced? " + bst.isBalanced());
        
        //delete 108
        System.out.println("\nDelete employee with ID 108 and Print");
        bst.delete(108);
        System.out.println("Updated list of employees:");
        bst.inOrder();
        System.out.println("BST balanced after deleted? " + bst.isBalanced());
        
        // Find employee with highest seniority
        System.out.println("\nEmployee with highest seniority:");
        Employee maxSeniority = bst.findMaxSeniority();
        if (maxSeniority != null) {
            System.out.println(maxSeniority);
        }
    }
}
