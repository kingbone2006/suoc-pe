import java.io.RandomAccessFile;

public class ReaderBST {
    class Node {
        Reader data;
        Node left, right;
        Node(Reader data) {
            this.data = data;
        }
    }

    Node root;

    public void ftraverse(RandomAccessFile f, Node root) throws Exception {
        if(root == null){
            return;
        }
        this.ftraverse(f, root.left);
        f.writeBytes("(" + root.data.id + "," + root.data.name + ")");
        this.ftraverse(f, root.right);
    }

    public void ftraverse(RandomAccessFile f) throws Exception {
        if (root == null) {
            f.writeBytes("Empty\r\n");
            return;
        }
        this.ftraverse(f, root);
    }

    public void insert(Reader r) {
        // ---------- Student's code starts from here ----------
        // Students are welcomed to use any helper function(s)

        // -----------------------------------------------------
    }

    public int countGreater(String id){
        int c = 0;
        // ---------- Student's code starts from here ----------
        // Students are welcomed to use any helper function(s)

        // -----------------------------------------------------
        return c;
    }
}